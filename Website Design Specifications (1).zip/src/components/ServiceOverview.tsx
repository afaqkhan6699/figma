import { Check } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function ServiceOverview() {
  const features = [
    "Custom WordPress theme development",
    "Performance optimization & SEO",
    "Responsive design for all devices"
  ];

  return (
    <section className="section-padding bg-[#f8f9fb]">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left - Screenshot/Illustration */}
          <div className="relative">
            <div className="bg-white rounded-xl card-shadow p-6">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1641567535859-c58187ac4954?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx8fHwxNzU5MTc2NjA5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="WordPress Dashboard Screenshot"
                className="w-full h-auto rounded-lg"
              />
            </div>
          </div>

          {/* Right - Content */}
          <div className="space-y-6">
            <h2 className="text-4xl font-bold text-[#111111]">
              Professional WordPress Solutions
            </h2>
            <p className="text-lg text-[#666666] leading-relaxed">
              We specialize in creating high-performance WordPress websites that not only look 
              amazing but also deliver exceptional user experiences. Our team combines technical 
              expertise with creative design to build websites that grow your business.
            </p>
            
            <div className="space-y-4 pt-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="bg-[#7243f2] rounded-full p-1 mt-1">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-[#111111] text-lg">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}