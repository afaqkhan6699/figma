import { Button } from "./ui/button";
import { Check } from "lucide-react";

export function Pricing() {
  const plans = [
    {
      name: "Starter",
      price: "$1,299",
      description: "Perfect for small businesses getting started",
      features: [
        "5-page custom website",
        "Responsive design",
        "Basic SEO setup",
        "Contact form integration",
        "3 months support"
      ],
      isHighlighted: false
    },
    {
      name: "Professional",
      price: "$2,499",
      description: "Ideal for growing businesses",
      features: [
        "10-page custom website",
        "Advanced functionality",
        "E-commerce integration",
        "Premium SEO optimization",
        "6 months support",
        "Performance optimization"
      ],
      isHighlighted: true
    },
    {
      name: "Enterprise",
      price: "$4,999",
      description: "For large-scale projects",
      features: [
        "Unlimited pages",
        "Custom plugins",
        "Advanced integrations",
        "Priority support",
        "12 months support",
        "Training included"
      ],
      isHighlighted: false
    }
  ];

  return (
    <section className="section-padding pricing-gradient">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-[#111111] mb-4">
            Choose Your Package
          </h2>
          <p className="text-lg text-[#666666] max-w-2xl mx-auto">
            Transparent pricing for WordPress development services that deliver results
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <div 
              key={index}
              className={`rounded-2xl p-8 ${
                plan.isHighlighted 
                  ? 'bg-[#7243f2] text-white card-shadow transform scale-105' 
                  : 'bg-white card-shadow'
              }`}
            >
              <div className="text-center mb-8">
                <h3 className={`text-2xl font-bold mb-2 ${
                  plan.isHighlighted ? 'text-white' : 'text-[#111111]'
                }`}>
                  {plan.name}
                </h3>
                <div className={`text-4xl font-bold mb-2 ${
                  plan.isHighlighted ? 'text-white' : 'text-[#7243f2]'
                }`}>
                  {plan.price}
                </div>
                <p className={`${
                  plan.isHighlighted ? 'text-gray-200' : 'text-[#666666]'
                }`}>
                  {plan.description}
                </p>
              </div>

              <div className="space-y-4 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-start space-x-3">
                    <div className={`rounded-full p-1 mt-1 ${
                      plan.isHighlighted ? 'bg-white' : 'bg-[#7243f2]'
                    }`}>
                      <Check className={`w-4 h-4 ${
                        plan.isHighlighted ? 'text-[#7243f2]' : 'text-white'
                      }`} />
                    </div>
                    <span className={`${
                      plan.isHighlighted ? 'text-white' : 'text-[#111111]'
                    }`}>
                      {feature}
                    </span>
                  </div>
                ))}
              </div>

              <Button 
                className={`w-full py-3 rounded-lg ${
                  plan.isHighlighted 
                    ? 'bg-white text-[#7243f2] hover:bg-gray-100' 
                    : 'bg-[#7243f2] text-white hover:bg-[#5128d0]'
                }`}
                onClick={() => window.open('https://makewebsitely.com/', '_blank')}
              >
                Get Started
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}