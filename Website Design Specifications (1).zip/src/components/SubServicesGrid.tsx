import { Code, Palette, Smartphone, Search, ShoppingCart, Shield } from "lucide-react";

export function SubServicesGrid() {
  const services = [
    {
      icon: Code,
      title: "Custom Development",
      description: "Tailored WordPress solutions built to your exact specifications and requirements."
    },
    {
      icon: Palette,
      title: "Theme Design",
      description: "Beautiful, responsive themes that perfectly represent your brand identity."
    },
    {
      icon: Smartphone,
      title: "Mobile Optimization",
      description: "Fully responsive designs that work flawlessly across all devices and screens."
    },
    {
      icon: Search,
      title: "SEO Optimization",
      description: "Built-in SEO best practices to help your website rank higher in search results."
    },
    {
      icon: ShoppingCart,
      title: "E-commerce Solutions",
      description: "Complete WooCommerce integration for powerful online selling capabilities."
    },
    {
      icon: Shield,
      title: "Security & Maintenance",
      description: "Ongoing security updates and maintenance to keep your website safe and fast."
    }
  ];

  return (
    <section className="section-padding bg-white">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-[#111111] mb-4">
            Our WordPress Services
          </h2>
          <p className="text-lg text-[#666666] max-w-2xl mx-auto">
            Comprehensive WordPress development services to bring your vision to life
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div 
                key={index} 
                className="bg-white rounded-xl card-shadow p-8 card-hover transition-all duration-300 hover:transform hover:-translate-y-1"
              >
                <div className="bg-[#7243f2] rounded-full w-16 h-16 flex items-center justify-center mb-6">
                  <IconComponent className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-[#111111] mb-3">
                  {service.title}
                </h3>
                <p className="text-[#666666] leading-relaxed">
                  {service.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}