import { Button } from "./ui/button";

export function FinalCTA() {
  return (
    <section className="section-padding purple-gradient-bg">
      <div className="container-custom">
        <div className="text-center max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Transform Your Business Online?
          </h2>
          <p className="text-xl text-gray-200 mb-8 leading-relaxed">
            Let's create a stunning WordPress website that
            drives results and grows your business. Get started
            with a free consultation and see how we can bring
            your vision to life.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-white text-[#7243f2] hover:bg-gray-100 px-8 py-4 rounded-lg text-lg font-medium"
              onClick={() => window.open('https://makewebsitely.com/', '_blank')}
            >
              Start Your Project
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-white text-[#7243f2] hover:bg-white hover:text-[#7243f2] px-8 py-4 rounded-lg text-lg font-medium"
              onClick={() => window.open('https://makewebsitely.com/', '_blank')}
            >
              Schedule Consultation
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}