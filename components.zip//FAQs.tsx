import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "./ui/accordion";

export function FAQs() {
  const faqs = [
    {
      question: "How long does it take to develop a WordPress website?",
      answer: "The timeline depends on the complexity of your project. A basic website typically takes 2-3 weeks, while more complex sites with custom functionality can take 4-8 weeks. We'll provide you with a detailed timeline during our initial consultation."
    },
    {
      question: "Do you provide ongoing maintenance and support?",
      answer: "Yes, we offer comprehensive maintenance packages that include security updates, backups, performance monitoring, and content updates. Our support packages range from 3 months to 12 months depending on your chosen plan."
    },
    {
      question: "Can you help migrate my existing website to WordPress?",
      answer: "Absolutely! We specialize in website migrations to WordPress. We'll handle the entire process including content migration, design adaptation, and ensuring all functionality is preserved during the transition."
    },
    {
      question: "Will my website be mobile-friendly and SEO optimized?",
      answer: "Yes, all our WordPress websites are built with responsive design principles and include basic SEO optimization. We ensure your site works perfectly on all devices and follows SEO best practices for better search engine visibility."
    },
    {
      question: "What happens if I need changes after the website is launched?",
      answer: "We include a revision period with all our packages, and ongoing support is available through our maintenance plans. For additional features or major changes, we can provide a separate quote for the work required."
    },
    {
      question: "Do you work with existing WordPress themes or only custom designs?",
      answer: "We offer both options! We can customize existing premium themes to match your brand, or create completely custom themes from scratch. The choice depends on your budget, timeline, and specific requirements."
    }
  ];

  return (
    <section className="section-padding bg-white">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-[#111111] mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-[#666666] max-w-2xl mx-auto">
            Get answers to common questions about our WordPress development services
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="border border-gray-200 rounded-lg px-6 data-[state=open]:border-[#7243f2]"
              >
                <AccordionTrigger className="text-left hover:no-underline py-6">
                  <span className="text-xl font-bold text-[#111111] pr-4">
                    {faq.question}
                  </span>
                </AccordionTrigger>
                <AccordionContent className="pb-6">
                  <p className="text-[#666666] leading-relaxed">
                    {faq.answer}
                  </p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}