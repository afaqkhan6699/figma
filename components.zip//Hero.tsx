import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  return (
    <section className="relative min-h-[700px] flex items-center bg-gradient-to-br from-white via-purple-50/30 to-indigo-50/40 overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#7243f2]/20 to-[#5128d0]/10 rounded-full transform translate-x-32 -translate-y-32 animate-pulse"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-gradient-to-tr from-[#7243f2]/10 to-transparent rounded-full transform -translate-x-20 translate-y-20"></div>
      <div className="absolute top-1/2 left-1/4 w-32 h-32 bg-[#7243f2]/5 rounded-full animate-bounce [animation-delay:2s]"></div>
      <div className="absolute top-1/4 right-1/3 w-20 h-20 bg-[#7243f2]/10 rounded-full animate-pulse [animation-delay:1s]"></div>

      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/3 w-2 h-2 bg-[#7243f2] rounded-full animate-ping [animation-delay:0.5s]"></div>
        <div className="absolute top-3/4 right-1/4 w-1 h-1 bg-[#7243f2] rounded-full animate-ping [animation-delay:1.5s]"></div>
        <div className="absolute top-1/2 right-2/3 w-1.5 h-1.5 bg-[#7243f2] rounded-full animate-ping [animation-delay:2.5s]"></div>
      </div>

      <div className="container-custom relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center px-[0px] py-[60px]">
          {/* Left content */}
          <div className="space-y-8">
            {/* Trust badges */}

            <div className="space-y-4">
              <div className="inline-block px-4 py-2 bg-[#7243f2]/10 text-[#7243f2] rounded-full text-sm font-medium">
                🚀 #1 WordPress Development Agency
              </div>
              <h1 className="text-6xl font-bold text-[#111111] leading-tight">
                WordPress Website
                <span className="block bg-gradient-to-r from-[#7243f2] to-[#5128d0] bg-clip-text text-transparent">
                  Development
                </span>
              </h1>
            </div>

            <p className="text-xl text-[#666666] leading-relaxed max-w-lg">
              Transform your business with custom WordPress
              solutions. We create stunning,
              performance-optimized websites that drive results
              and engage your audience.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 py-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-[#7243f2]">
                  500+
                </div>
                <div className="text-sm text-[#666666]">
                  Projects
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-[#7243f2]">
                  50+
                </div>
                <div className="text-sm text-[#666666]">
                  Happy Clients
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-[#7243f2]">
                  5★
                </div>
                <div className="text-sm text-[#666666]">
                  Rating
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                size="lg"
                className="bg-[#7243f2] hover:bg-[#5128d0] text-white px-8 py-4 rounded-lg text-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
                onClick={() =>
                  window.open(
                    "https://makewebsitely.com/",
                    "_blank",
                  )
                }
              >
                Get Started Today
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-[#7243f2] text-[#7243f2] hover:bg-[#7243f2] hover:text-white px-8 py-4 rounded-lg text-lg transition-all duration-300"
                onClick={() =>
                  window.open(
                    "https://makewebsitely.com/",
                    "_blank",
                  )
                }
              >
                View Portfolio
              </Button>
            </div>

            {/* Social proof */}
          </div>

          {/* Right content - Enhanced mockup */}
          <div className="relative">
            {/* Main mockup */}
            <div className="relative bg-white rounded-2xl card-shadow p-6  hover:scale-102 transition-transform duration-500">
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-br from-[#7243f2] to-[#5128d0] rounded-full opacity-20 animate-pulse"></div>

              {/* Custom WordPress Dashboard Graphic */}
              <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-6">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-[#7243f2] rounded-lg flex items-center justify-center">
                      <span className="text-white font-bold text-sm">
                        WP
                      </span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-800">
                        WordPress Dashboard
                      </div>
                      <div className="text-xs text-gray-500">
                        Performance Analytics
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-1">
                    <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                  </div>
                </div>

                {/* Stats Cards */}
                <div className="grid grid-cols-3 gap-3 mb-6">
                  <div className="bg-white rounded-lg p-3 text-center shadow-sm">
                    <div className="text-2xl font-bold text-[#7243f2]">
                      98%
                    </div>
                    <div className="text-xs text-gray-600">
                      Performance
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-3 text-center shadow-sm">
                    <div className="text-2xl font-bold text-green-500">
                      2.1s
                    </div>
                    <div className="text-xs text-gray-600">
                      Load Time
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-3 text-center shadow-sm">
                    <div className="text-2xl font-bold text-blue-500">
                      100%
                    </div>
                    <div className="text-xs text-gray-600">
                      SEO
                    </div>
                  </div>
                </div>

                {/* Chart Area */}
                <div className="bg-white rounded-lg p-4 mb-4 shadow-sm">
                  <div className="flex items-center justify-between mb-3">
                    <div className="text-sm font-semibold text-gray-700">
                      Traffic Overview
                    </div>
                    <div className="text-xs text-gray-500">
                      Last 30 days
                    </div>
                  </div>
                  <div className="flex items-end space-x-1 h-16">
                    {[
                      40, 65, 45, 80, 55, 90, 70, 85, 60, 95,
                      75, 88,
                    ].map((height, index) => (
                      <div
                        key={index}
                        className="bg-gradient-to-t from-[#7243f2] to-[#7243f2]/60 rounded-sm flex-1 transition-all duration-300 hover:from-[#5128d0]"
                        style={{ height: `${height}%` }}
                      ></div>
                    ))}
                  </div>
                </div>

                {/* Table */}
                <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                  <div className="px-4 py-2 bg-gray-50 border-b">
                    <div className="text-sm font-semibold text-gray-700">
                      Recent Pages
                    </div>
                  </div>
                  <div className="divide-y divide-gray-100">
                    {[
                      {
                        page: "/home",
                        views: "2.4K",
                        status: "online",
                      },
                      {
                        page: "/services",
                        views: "1.8K",
                        status: "online",
                      },
                      {
                        page: "/contact",
                        views: "950",
                        status: "online",
                      },
                    ].map((item, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between px-4 py-2 hover:bg-gray-50"
                      >
                        <div className="flex items-center space-x-2">
                          <div
                            className={`w-2 h-2 rounded-full ${item.status === "online" ? "bg-green-400" : "bg-gray-400"} animate-pulse`}
                          ></div>
                          <span className="text-sm text-gray-700">
                            {item.page}
                          </span>
                        </div>
                        <span className="text-sm font-medium text-[#7243f2]">
                          {item.views}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Fast Loading badge */}
              <div className="absolute -top-10 -left-10 bg-gradient-to-r from-[#7243f2] to-[#5128d0] rounded-xl p-4 text-white shadow-lg transform -rotate-40">
                <div className="text-sm font-medium">
                  Fast Loading
                </div>
                <div className="text-2xl font-bold">
                  ⚡ 2.1s
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}