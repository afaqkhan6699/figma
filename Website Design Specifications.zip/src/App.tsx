import { Hero } from "./components/Hero";
import { ServiceOverview } from "./components/ServiceOverview";
import { SubServicesGrid } from "./components/SubServicesGrid";
import { Pricing } from "./components/Pricing";
import { FAQs } from "./components/FAQs";
import { FinalCTA } from "./components/FinalCTA";

export default function App() {
  return (
    <div className="min-h-screen">
      <Hero />
      <ServiceOverview />
      <SubServicesGrid />
      <Pricing />
      <FAQs />
      <FinalCTA />
    </div>
  );
}